//Name: Nishal Bhim//

//Student ID#: 20210614//

//Course Code: INFO-0201//

//Course Name: Object-Oriented Programming//

//Date: 9th October 2022//

//Lecturer: Dr. Steve Warner//

//Assignment: Assignment #2 - Bank Operations//

//Program Name: Bank Operations//

//Program Description: This program will continually ask the user what task they would like to accomplish until they quit. Furthermore, an array list would be used as a storage location for the users account numbers and corresponding initial balances//

//Import statement for Java Scanner Utility//
import java.util.Scanner;

public class Bank {
	
	public static String choice = "Yes";   //Statement that sets 'choice' to yes//

	public static void main(String[] args) {
		
		//Variable Declaration//
		String selection;
		
		Scanner option = new Scanner (System.in);   //Statement that utilizes a Scanner via the object, 'option'//
		Account BankAccount = new Account();   //Statement that creates the 'BankAccount' object with the 'Account' class//
		

		//If statements to call the corresponding Method based on the user's choice within a 'do-while' loop to ensure that the welcome message is displayed while the choice is yes until the user quits//
				
		do {		
			System.out.println(BankAccount.welcmsg);
			selection = option.nextLine();	
			
			if (selection.equals("o"))
			{
				BankAccount.open();

				choice = BankAccount.choice;  //Statement that accepts the choice of the user after being prompted in the specified Instance Method//
			}
				
			if (selection.equals("d"))
			{
				BankAccount.deposit();
				
				choice = BankAccount.choice;
			}
			if (selection.equals("se"))
			{
				BankAccount.select();
			}
			if (selection.equals("c"))
			{
				BankAccount.close();
				
				choice = BankAccount.choice;
			}
			if (selection.equals("w"))
			{
				BankAccount.withdraw();
				
				choice = BankAccount.choice;
			}
			if (selection.equals("q"))
			{
				BankAccount.quit();
				choice = "No";   //Statement that sets choice to no since the user wants to quit//
			}
		} while (choice.equals("Yes"));   //While section of loop to execute code while choice is yes//
		
		System.out.println("Okay have a blessed day :)");   //Friendly goodbye message//
		
		option.close();   //Close scanner object//
		
	}
}
