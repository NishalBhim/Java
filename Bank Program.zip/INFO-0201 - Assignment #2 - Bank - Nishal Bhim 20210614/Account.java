
//Import statements for Java Utilities//
import java.util.Scanner;
import java.util.ArrayList;


public class Account {

	//Instance Variable Declaration//
	public double balance;
	public String choice;
	public String num;
	public String currentAcct;
	public double deposit;
	public double withdraw;
	public String selection;
	
	//Welcome message to be displayed//
	public String welcmsg = "\nWhat would you like to do?\n\no Open Account\nd Deposit\nse Select Account\nc Close Account\nw Withdraw\nq Quit\n "; 
	
	Scanner scan = new Scanner (System.in);
	
	//Array List and Array List object Declaration//
	ArrayList<String> acctnumList = new ArrayList<String>();
	
	
	
	public Account ()
	{
		balance = 0.0;   //Sets the balance to zero//
		
		//Addition of pre-existing accounts//
		acctnumList.add("123-456");
		acctnumList.add("456-789");
		
		
	} 
	
	//'Open' Instance Method//
	public void open() 
	{
		
		System.out.println("Enter your 6 digit account number: ");   //Statement that prompts the user to enter their account number//
		num = scan.nextLine();   //Statement that stores the number entered into the 'num' Instance Variable//
		acctnumList.add(num);   //Statement that adds the number entered to the Array List//
		
			currentAcct = num;   //Statement that sets the number entered as the current account//
	
		System.out.println("Enter an initial balance: ");   //Statement that prompts the user to enter their initial balance//
		balance = scan.nextDouble();   //Statement that stores the balance into the 'balance' Instance Variable//
		
		System.out.println("Would you like to continue? (Yes, No)");   //Statement that asks the user if they would like to continue//
		
		scan.nextLine(); //consume new line
		
		choice = scan.nextLine();
		//Statement that stores the users choice//
			
		}
	
	//'Deposit' Instance Method//
	public void deposit()
	{
		//If statement that displays if there is not an active current account//
		if (currentAcct == null) 
		{
			System.out.println("Please enter your 6 digit account number: ");
			num = scan.nextLine();
			currentAcct = num;
		}
		
		System.out.println("Please enter the amount you wish to deposit: ");   //Statement that prompts the user to enter the deposit value//
		
		deposit = scan.nextInt();   //Statement that stores the deposit//
		balance = balance + deposit;   //Statement that adds the deposited amount to the balance//
		
		System.out.printf("Your New Balance is $%.2f.\n",balance); 
			
		scan.nextLine(); //consume new line
		
		System.out.println("Would you like to continue? (Yes, No)");   //Statement that asks the user if they would like to continue//
		choice = scan.nextLine();   //Statement that stores the users choice//
			
	}
	
	//'Select' Instance Method//
	public void select()
	{
		//If statement that determines if the current account is an element of the array list//
		if (currentAcct == null) 
		{ 
			
			System.out.println("Please enter your 6 digit account number: ");
			num = scan.nextLine();
			
			//If statement that shows what will happen if the account number is an element of the array list//
			if (acctnumList.contains(num)) 
			{
				
				currentAcct = num;
				
				System.out.println("\nCurrent Account Selected = "+currentAcct+"\n");
				System.out.printf("Your Balance is $%.2f.\n",balance); 
				
			} 
			//Else statement in the event that the account entered does not exist//
			else { System.out.println("Account Does Not Exist"); }	
		} 
		//Else statement that displays the information if the account selected was an element of the array list//
		else 
		{
			System.out.println("\nCurrent Account Selected = "+currentAcct+"\n\n");
			System.out.printf("Your Balance is $%.2f.\n",balance); 	
		}
		
		
		System.out.println("Would you like to continue? (Yes, No)");   //Statement that asks the user if they would like to continue//
		choice = scan.nextLine();   //Statement that stores the users choice//
	
	}
	
	//'Close' Instance Method//
	public void close()
	{
		//If statement that displays if there is not a current account selected//
		if (currentAcct == null) 
		{
			System.out.println("Please enter your 6 digit account number: ");
			num = scan.nextLine();
			currentAcct = num;
		}
		//Statement that displays when the current account have been successfully closed//
		System.out.println("\nAccount  "+currentAcct+" has been closed\n");   
		acctnumList.remove(currentAcct);
			
			//Statements that returns the current account to 'null' and balance to zero//
			currentAcct = null;
			balance = 0.0;
		
					
		System.out.println("Would you like to continue? (Yes, No)");   //Statement that asks the user if they would like to continue//
		choice = scan.nextLine();   //Statement that stores the users choice//
			
	}
	
	//'Withdraw' Instance Method//
	public void withdraw()
	{
		//If Statement that displays if a current account is not selected//
		if (currentAcct == null) 
		{
			System.out.println("Please enter your 6 digit account number: ");
			num = scan.nextLine();
			currentAcct = num;
		}
		//Statements that execute if a current account is selected//
		System.out.println("Please enter the amount to withdraw: ");   //Statement that prompts the user to enter the withdrawal amount//
		withdraw = scan.nextDouble();   //Statement that stores the withdrawal amount//
		
		scan.nextLine();		
		
		balance = balance - withdraw;   //Statement that calculates the remaining balance by subtracting the withdrawal amount from the current balance//
		
		System.out.printf("Your New Balance is $%.2f.\n",balance);   //Statement that displays the balance in an appropriate format// 
		
		System.out.println("Would you like to continue? (Yes, No)");   //Statement that asks the user if they would like to continue//
		choice = scan.nextLine();   //Statement that stores the users choice//
			
	}
	
	//'Quit' Instance Method//
	public void quit()
	{
		//Method is empty because the statement is already displayed in the main program, 'Bank'//
	}
	
}