
import java.util.Scanner;

public class Salesrep {
	
	String choice;
	Scanner scan;
	
	public void task()  
	{
		Supplier sr = new Supplier();
		Inventory i = new Inventory();
		Cashier c = new Cashier();
	
		
		scan = new Scanner(System.in);
		
		String sel;

		String brkloop = "s";
		
		//Prompts the Sales rep to select a task//
		System.out.println("\nHello Sales rep, what would you like to do today?\n(a) Add Inventory\n(b) Update Inventory\n(c) Add Supplier\n(d) Update Supplier\n(e) Record Sale Transaction");
		
		//Exception handling to ensure that the valid entry is accepted, otherwise display an error message//
		try
		{
			do {
				sel = scan.nextLine();
				
				//IF statements that calls the method of the corresponding class based on the Sales rep's selection//
					if (sel.equals("a") || sel.equals("A"))   //Enables the user to enter either an upper case letter or a lower case letter//
					{
						i.add();
						break;
					}
					if (sel.equals("b") || sel.equals("B"))
					{
						i.update();
						break;
					}
					if (sel.equals("c") || sel.equals("C"))
					{
						sr.add();
						break;
					}
					if (sel.equals("d") || sel.equals("D"))
					{
						sr.update();
						break;
					}
					if (sel.equals("e") || sel.equals("E"))
					{
						c.receipt();
						break;
					}
					
					System.out.println("Error: you did not select one of the listed options, please try again");
					
					
			} while (brkloop.equals("s"));
			
			salesloop();
				
		}
		
		catch (Exception e)
		{
			System.out.println(e);
	        e.printStackTrace();		
	    }
		
	}
	
	public void salesloop() 
	{
		
		//prompt to continue//
		System.out.println("\n\nWould you like to continue Sales rep (Y or N)? ");
		
		choice = scan.nextLine();
		
		//IF statements that calls the method of the corresponding class if the Sales rep's choice is yes and displays a farewell message of not//
		if (choice.equals("Y") || choice.equals("y"))
		{
			task();
		}
		if (choice.equals("N") || choice.equals("n"))
		{
			System.out.println("Okay you have been logged out, have a blessed day Sales rep :)");
		}
		
		scan.close();
		
	}

}
