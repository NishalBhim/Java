
public class Sales extends MonthlySales{
	//Class that extends the MonthlySales class//
}
