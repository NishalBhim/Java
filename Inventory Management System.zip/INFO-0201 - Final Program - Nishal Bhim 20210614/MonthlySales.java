
public abstract class MonthlySales 
{
	public void transactions()
	{
		//Displays the Monthly Sales of Busy Builders//
		System.out.println("\n\t\t****************************************");
		System.out.println("\n\t\t*\tM O N T H L Y\tS A L E S\t*");
		System.out.println("\n\t\t****************************************");		
		System.out.println("\n________________________________________________________________________________________");
		System.out.println("\nSaleID\t\tDate_of_sale\t Item\t\t\t      Amount\tCost");
		System.out.println("________________________________________________________________________________________");
		
			System.out.println("\n2500\t\t05/11/22\tPower Drill\t\t\t2\t$700.00");
			System.out.println("\n4521\t\t05/11/22\tPress. Cooker\t\t\t1\t$238.45");
			System.out.println("\n4866\t\t05/11/22\tUtil Hammer\t\t\t3\t$343.50");
			System.out.println("\n1023\t\t05/11/22\tStep T/Can\t\t\t1\t$114.20");
			System.out.println("\n7895\t\t05/11/22\tScrewdriver (FH version)\t5\t$197.25");
				System.out.println("________________________________________________________________________________________");
			
			System.out.println("\n*********************************");
			System.out.println("\n* Total Monies gained: $1593.40 *");   //Displays the Total monies gained//
			System.out.println("\n*********************************");


	
	}
}
