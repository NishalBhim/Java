
import java.util.Scanner;

public abstract class Print {
	
	public void receipt()
	{
		//Variable Declaration//
		
		Scanner scan = new Scanner(System.in);
		Salesrep l = new Salesrep();
		
		//Prompts the Sales rep to select the item that is to be purchased//
		System.out.println("Select an item:\n(a) Power Drill\n(b) Util Hammer\n(c) Screwdriver - PH version\n(d) Screwdriver - FH version\n(e) Stept/Can\\n(f) Liq. Soap Disp\n(g) Press. Cooker\n(h) 10''F/Pan\n(i) 6P-Fd Ctnr\n(j) 3Qt A/Fr");
		
		try
		{
			String sel = scan.nextLine();
			
			//IF statement outlining what will occur if option a is chosen//
			if (sel.equals("A") || sel.equals("a"))
			{
				int pdrlv = 12;
				int amount;
				
				System.out.println("How many Power Drills were purchased?");   //Prompts for the number of items bought//
				amount = scan.nextInt(); scan.nextLine();
				
				double total = amount * 350.0;   //calculates the total//
				double rem = 12 - amount;   //calculates the number of items remaining//
				
				System.out.println("Enter the Transaction ID: ");   //Prompts for the Transaction ID//
				int id = scan.nextInt(); scan.nextLine();
				
				System.out.println("Enter the date of the transaction (Format: dd/mm/yy): ");   //Prompts for the date of the transaction//
				String date1 = scan.nextLine();
				
				
				//The receipt containing the necessary information is displayed//
				System.out.println("\n* R E C E I P T *");
				System.out.println("\nTrans. ID: "+id+"\nDate: "+date1+"\nItem Name: Power Drills\nAmount: "+amount+"\nTotal due: $"+total+"");
				
				if (rem <= pdrlv)
				{
					System.out.println("\nSuccess! However, you need to order more Power Drills because the Stock Level is equal to or below the Re-order Level");
				}
			}
			
			//IF statement outlining what will occur if option b is chosen//
			if (sel.equals("B") || sel.equals("b"))
			{
				int hrlv = 10;
				int amount;
				
				System.out.println("How many Util Hammers were purchased?");
				amount = scan.nextInt(); scan.nextLine();
				
				double total = amount * 114.50;
				double rem = 12 - amount;
				
				System.out.println("Enter the Transaction ID: ");
				int id = scan.nextInt(); scan.nextLine();
				
				System.out.println("Enter the date of the transaction (Format: dd/mm/yy): ");
				String date1 = scan.nextLine();
				
				
				
				System.out.println("\n* R E C E I P T *");
				System.out.println("\nTrans. ID: "+id+"\nDate: "+date1+"\nItem Name: Util Hammers\nAmount: "+amount+"\tnTotal due: $"+total+"");
				
				if (rem <= hrlv)
				{
					System.out.println("\nSuccess! However, you need to order more Util Hammers because the Stock Level is equal to or below the Re-order Level");
				}
			}
			
			//IF statement outlining what will occur if option c is chosen//
			if (sel.equals("C") || sel.equals("c"))
			{
				int sprlv = 10;
				int amount;
				
				System.out.println("How many Screwdrivers (PH version) were purchased?");
				amount = scan.nextInt(); scan.nextLine();
				
				double total = amount * 47.95;
				double rem = 12 - amount;
				
				System.out.println("Enter the Transaction ID: ");
				int id = scan.nextInt(); scan.nextLine();
				
				System.out.println("Enter the date of the transaction (Format: dd/mm/yy): ");
				String date1 = scan.nextLine();
				

				System.out.println("\n* R E C E I P T *");
				System.out.println("\nTrans. ID: "+id+"\nDate: "+date1+"\nItem Name: Screwdrivers (PH version)\nAmount: "+amount+"\nTotal due: $"+total+"");
				
				if (rem <= sprlv)
				{
					System.out.println("\nSuccess! However, you need to order more Screwdrivers (PH version) because the Stock Level is equal to or below the Re-order Level");
				}
			}
			
			//IF statement outlining what will occur if option d is chosen//
			if (sel.equals("D") || sel.equals("d"))
			{
				int sfrlv = 10;
				int amount;
				
				System.out.println("How many Screwdrivers (FH version) were purchased?");
				amount = scan.nextInt(); scan.nextLine();
				
				double total = amount * 39.45;
				double rem = 12 - amount;
				
				System.out.println("Enter the Transaction ID: ");
				int id = scan.nextInt(); scan.nextLine();
				
				System.out.println("Enter the date of the transaction (Format: dd/mm/yy): ");
				String date1 = scan.nextLine();
				
				System.out.println("\n* R E C E I P T *");
				System.out.println("\nTrans. ID: "+id+"\nDate: "+date1+"\nItem Name: Screwdrivers (FH version)\nAmount: "+amount+"\nTotal due: $"+total+"");
				
				if (rem <= sfrlv)
				{
					System.out.println("\nSuccess! However, you need to order more Screwdrivers (FH version) because the Stock Level is equal to or below the Re-order Level");
				}
			}
			
			//IF statement outlining what will occur if option e is chosen//
			if (sel.equals("E") || sel.equals("e"))
			{
				int strlv = 5;
				int amount;
				
				System.out.println("How many Step T/Can were purchased?");
				amount = scan.nextInt(); scan.nextLine();
				
				double total = amount * 114.20;
				double rem = 12 - amount;
				
				System.out.println("Enter the Transaction ID: ");
				int id = scan.nextInt(); scan.nextLine();
				
				System.out.println("Enter the date of the transaction (Format: dd/mm/yy): ");
				String date1 = scan.nextLine();
				
				System.out.println("\n* R E C E I P T *");
				System.out.println("\nTrans. ID: "+id+"\nDate: "+date1+"\nItem Name: Step T/Can\nAmount: "+amount+"\nTotal due: $"+total+"");
				
				if (rem <= strlv)
				{
					System.out.println("\nSuccess! However, you need to order more Step T/Can because the Stock Level is equal to or below the Re-order Level");
				}
			}
			
			//IF statement outlining what will occur if option f is chosen//
			if (sel.equals("F") || sel.equals("f"))
			{
				int lsrlv = 10;
				int amount;
				
				System.out.println("How many Liq. Soap Disp were purchased?");
				amount = scan.nextInt(); scan.nextLine();
				
				double total = amount * 48.50;
				double rem = 12 - amount;
				
				System.out.println("Enter the Transaction ID: ");
				int id = scan.nextInt(); scan.nextLine();
				
				System.out.println("Enter the date of the transaction (Format: dd/mm/yy): ");
				String date1 = scan.nextLine();
				
				System.out.println("\n* R E C E I P T *");
				System.out.println("\nTrans. ID: "+id+"\nDate: "+date1+"\nItem Name: Press. Cookers\nAmount: "+amount+"\nTotal due: $"+total+"");
				
				if (rem <= lsrlv)
				{
					System.out.println("\nSuccess! However, you need to order more Liq. Soap Disp because the Stock Level is equal to or below the Re-order Level");
				}
			}
			
			//IF statement outlining what will occur if option g is chosen//
			if (sel.equals("G") || sel.equals("g"))
			{
				int psrlv = 5;
				int amount;
				
				System.out.println("How many Press. Cookers were purchased?");
				amount = scan.nextInt(); scan.nextLine();
				
				double total = amount * 238.45;
				double rem = 12 - amount;
				
				System.out.println("Enter the Transaction ID: ");
				int id = scan.nextInt(); scan.nextLine();
				
				System.out.println("Enter the date of the transaction (Format: dd/mm/yy): ");
				String date1 = scan.nextLine();
				
				System.out.println("\n* R E C E I P T *");
				System.out.println("\nTrans. ID: "+id+"\nDate: "+date1+"\nItem Name: Press. Cookers\nAmount: "+amount+"\nTotal due: $"+total+"");
				
				if (rem <= psrlv)
				{
					System.out.println("\nSuccess! However, you need to order more Press. Cookers because the Stock Level is equal to or below the Re-order Level");
				}
			}
			
			//IF statement outlining what will occur if option h is chosen//
			if (sel.equals("H") || sel.equals("h"))
			{
				int prlv = 8;
				int amount;
				
				System.out.println("How many 10''F/Pans were purchased?");
				amount = scan.nextInt(); scan.nextLine();
				
				double total = amount * 195.95;
				double rem = 12 - amount;
				
				System.out.println("Enter the Transaction ID: ");
				int id = scan.nextInt(); scan.nextLine();
				
				System.out.println("Enter the date of the transaction (Format: dd/mm/yy): ");
				String date1 = scan.nextLine();
				
				System.out.println("\n* R E C E I P T *");
				System.out.println("\nTrans. ID: "+id+"\nDate: "+date1+"\nItem Name: 10''F/Pans\nAmount: "+amount+"\nTotal due: $"+total+"");
				
				if (rem <= prlv)
				{
					System.out.println("\nSuccess! However, you need to order more 10''F/Pans because the Stock Level is equal to or below the Re-order Level");
				}
			}
			
			//IF statement outlining what will occur if option i is chosen//
			if (sel.equals("I") || sel.equals("i"))
			{
				int pfrlv = 8;
				int amount;
				
				System.out.println("How many 6P-Fd Ctnr were purchased?");
				amount = scan.nextInt(); scan.nextLine();
				
				double total = amount * 94.85;
				double rem = 12 - amount;
				
				System.out.println("Enter the Transaction ID: ");
				int id = scan.nextInt(); scan.nextLine();
				
				System.out.println("Enter the date of the transaction (Format: dd/mm/yy): ");
				String date1 = scan.nextLine();
				
				System.out.println("\n* R E C E I P T *");
				System.out.println("\nTrans. ID: "+id+"\nDate: "+date1+"\nItem Name: 6P-Fd Ctnr\nAmount: "+amount+"\nTotal due: $"+total+"");
				
				if (rem <= pfrlv)
				{
					System.out.println("\nSuccess! However, you need to order more 6P-Fd Ctnr because the Stock Level is equal to or below the Re-order Level");
				}
			}
			
			//IF statement outlining what will occur if option j is chosen//
			if (sel.equals("J") || sel.equals("j"))
			{
				int brlv = 10;
				int amount;
				
				System.out.println("How many 3Qt A/Fr were purchased?");
				amount = scan.nextInt(); scan.nextLine();
				
				double total = amount * 432.55;
				double rem = 12 - amount;
				
				System.out.println("Enter the Transaction ID: ");
				int id = scan.nextInt(); scan.nextLine();
				
				System.out.println("Enter the date of the transaction (Format: dd/mm/yy): ");
				String date1 = scan.nextLine();
				
				System.out.println("\n* R E C E I P T *");
				System.out.println("\nTrans. ID: "+id+"\nDate: "+date1+"\nItem Name: 3Qt A/Fr\nAmount: "+amount+"\nTotal due: $"+total+"");
				
				if (rem <= brlv)
				{
					System.out.println("\nSuccess! However, you need to order more 3Qt A/Fr because the Stock Level is equal to or below the Re-order Level");
				}
			}
		}
		
		catch (Exception e)
		{
			System.out.println("Error: you did not choose one of the listed items");
		}
		
	}

}
