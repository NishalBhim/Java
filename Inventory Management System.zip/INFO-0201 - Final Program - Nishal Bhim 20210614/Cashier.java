
public class Cashier extends Print{
	//Class that extends to the 'Print' Abstract class//
}
