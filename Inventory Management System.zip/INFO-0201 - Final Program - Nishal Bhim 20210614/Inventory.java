
import java.util.Scanner;

public class Inventory {
	
	Salesrep sr = new Salesrep();
	
	public void add()
	{
		String reply = "";
		
		do {
		Scanner scan = new Scanner(System.in);
		//AddInvenLoop l = new AddInvenLoop();
		
		//Prompts the Sales rep to enter the Item's attributes//
		System.out.println("Enter the item's ID: ");
			String ID = scan.nextLine();
		System.out.println("Enter the item's Name: ");
			String name = scan.nextLine();
		System.out.println("Enter the item's Category: ");
			String cat = scan.nextLine();
		System.out.println("Enter the item's Unit Cost: ");
			double uc = scan.nextDouble(); scan.nextLine();
		System.out.println("Enter the item's Reorder Level: ");
			int rlv = scan.nextInt(); scan.nextLine();
		System.out.println("Enter the item's Stock Level: ");
			int slv = scan.nextInt();
			
			scan.nextLine();   //consumes a line//
			
		System.out.println("Enter the item's Supplier: ");
			String s = scan.nextLine();
		System.out.println("Enter the item's Quantity bought: ");
			int qtyb = scan.nextInt();
			
			scan.nextLine();
			
		
		//Confirmation statement//
				System.out.println("Is this the Item you wish to add (Y or N):\n\nID:"+ID+"\nName:"+name+
							"\nCategory:"+cat+"\nUnit Cost:$"+uc+"\nReorder Level:"+rlv+
							"\nStock Level:"+slv+"\nSupplier:"+s+"\nQuantity bought:"+qtyb+"");
			
			reply = scan.nextLine();
		
			//IF statements to be executed based on the Sales rep confirmation//
			if (reply.equals("Y") || reply.equals("y"))
			{
				System.out.println("Item successfully added :)");
				break;
			}
			if (reply.equals("N") || reply.equals("n"))
			{
				System.out.println("Okay, please re-enter information");
			}
			
		} while (reply.toUpperCase().equals("N")); 
				
		//scan.close();
		
	}
	
	public void update()
	{
		String sel;
		
		Scanner s = new Scanner(System.in);
		
		//Prompts the Sales rep to select an item to update//
		System.out.println("What Item would you like to update?\n(a) Power Drill\n(b) Util Hammer\n(c) Screwdriver - PH version\n(d) Screwdriver - FH version\n(e) Stept/Can\n(f) Liq. Soap Disp\n(g) Press. Cooker\n(h) 10''F/Pan\n(i) 6P-Fd Ctnr\n(j) 3Qt A/Fr");
		sel = s.nextLine();
		
		//IF statements that outlines what will be done based on the Sales rep's selection//
		if(sel.equals("a") || sel.equals("A"))
		{
			int pdrlv = 12;
			
			//Prompts the user to add or remove an amount from the item//
			System.out.println("Would you like to add or remove from the item Power Drill (A = add, R = remove)");
			String choice = s.nextLine();
			
				//IF statements that outlines what will happen based on the Sales rep's choice//
				if (choice.equals("A") || choice.equals("a"))
				{
					System.out.println("Okay, how much would you like to add: ");
					int num = s.nextInt(); s.nextLine();
					 
					int result = num + 18;
					
					System.out.printf("Success! you now have %d Power Drills",result);
				}
				if (choice.equals("R") || choice.equals("r"))
				{
					System.out.println("Okay, how much would you like to remove: ");
					int num = s.nextInt(); s.nextLine();
					
					int result = 18 - num;
					
					System.out.printf("Success! you now have %d Power Drills ",result);
					if (result <= pdrlv)
					{
						System.out.println("\n* However, you have to order more Power Drills because the Stock level is equal to or below the Reorder level *");
					}
				}
		
		}
			
					
		if (sel.equals("b") || sel.equals("B"))
		{
			int hrlv = 10;
			System.out.println("Would you like to add or remove from the item Util Hammer (A = add, R = remove)");
			String hchoice = s.nextLine();
				if (hchoice.equals("A") || hchoice.equals("a"))
				{
					System.out.println("Okay, how much would you like to add: ");
					int num = s.nextInt(); s.nextLine();
					
					int result = num + 16;
					
					System.out.printf("Success! you now have %d Util Hammers",result);
				}
				if (hchoice.equals("R") || hchoice.equals("r"))
				{
					System.out.println("Okay, how much would you like to remove: ");
					int num = s.nextInt(); s.nextLine();
					
					int result = 16 - num;
					
					System.out.printf("Success! you now have %d Util Hammers",result);
					if (result <= hrlv)
					{
						System.out.println("\n* However, you have to order more Util Hammers because the Stock level is equal to or below the Reorder level *");
					}


				}
		}
		
		if(sel.equals("c") || sel.equals("C"))
		{
			int sprlv = 10;
			System.out.println("Would you like to add or remove from the item Screwdrivers (PH version) (A = add, R = remove)");
			String choice = s.nextLine();
				if (choice.equals("A") || choice.equals("a"))
				{
					System.out.println("Okay, how much would you like to add: ");
					int num = s.nextInt(); s.nextLine();
					
					int result = num + 11;
					
					System.out.printf("Success! you now have %d Screwdrivers (PH version)",result);
				}
				if (choice.equals("R") || choice.equals("r"))
				{
					System.out.println("Okay, how much would you like to remove: ");
					int num = s.nextInt(); s.nextLine();
					
					int result = 11 - num;
					
					System.out.printf("Success! you now have %d Screwdrivers (PH version) ",result);
					if (result <= sprlv)
					{
						System.out.println("\n* However, you have to order more Screwdrivers (PH version) because the Stock level is equal to or below the Reorder level *");
					}
				}
		}
		
		if(sel.equals("d") || sel.equals("D"))
		{
			int sfrlv = 10;
			System.out.println("Would you like to add or remove from the item Screwdrivers (FH version) (A = add, R = remove)");
			String choice = s.nextLine();
				if (choice.equals("A") || choice.equals("a"))
				{
					System.out.println("Okay, how much would you like to add: ");
					int num = s.nextInt(); s.nextLine();
					
					int result = num + 22;
					
					System.out.printf("Success! you now have %d Power Drills",result);
				}
				if (choice.equals("R") || choice.equals("r"))
				{
					System.out.println("Okay, how much would you like to remove: ");
					int num = s.nextInt(); s.nextLine();
					
					int result = 22 - num;
					
					System.out.printf("Success! you now have %d Screwdrivers (FH version) ",result);
					if (result <= sfrlv)
					{
						System.out.println("\n* However, you have to order more Screwdrivers (FH version) because the Stock level is equal to or below the Reorder level *");
					}
				}
		}
		
		if(sel.equals("e") || sel.equals("E"))
		{
			int strlv = 5;
			System.out.println("Would you like to add or remove from the item Step T/Can (A = add, R = remove)");
			String choice = s.nextLine();
				if (choice.equals("A") || choice.equals("a"))
				{
					System.out.println("Okay, how much would you like to add: ");
					int num = s.nextInt(); s.nextLine();
					
					int result = num + 7;
					
					System.out.printf("Success! you now have %d Step T/Can",result);
				}
				if (choice.equals("R") || choice.equals("r"))
				{
					System.out.println("Okay, how much would you like to remove: ");
					int num = s.nextInt(); s.nextLine();
					
					int result = 7 - num;
					
					System.out.printf("Success! you now have %d Step T/Can ",result);
					if (result <= strlv)
					{
						System.out.println("\n* However, you have to order more Step T/Can because the Stock level is equal to or below the Reorder level *");
					}
				}
		}
		
		if(sel.equals("f") || sel.equals("F"))
		{
			int lsrlv = 10;
			System.out.println("Would you like to add or remove from the item Liq. Soap Disp (A = add, R = remove)");
			String choice = s.nextLine();
				if (choice.equals("A") || choice.equals("a"))
				{
					System.out.println("Okay, how much would you like to add: ");
					int num = s.nextInt(); s.nextLine();
					
					int result = num + 13;
					
					System.out.printf("Success! you now have %d Liq. Soap Disp",result);
				}
				if (choice.equals("R") || choice.equals("r"))
				{
					System.out.println("Okay, how much would you like to remove: ");
					int num = s.nextInt(); s.nextLine();
					
					int result = 13 - num;
					
					System.out.printf("Success! you now have %d Liq. Soap Disp ",result);
					if (result <= lsrlv)
					{
						System.out.println("\n* However, you have to order more Liq. Soap Disp because the Stock level is equal to or below the Reorder level *");
					}
				}
		}
		
		if(sel.equals("g") || sel.equals("G"))
		{
			int psrlv = 5;
			System.out.println("Would you like to add or remove from the item Press. Cooker (A = add, R = remove)");
			String choice = s.nextLine();
				if (choice.equals("A") || choice.equals("a"))
				{
					System.out.println("Okay, how much would you like to add: ");
					int num = s.nextInt(); s.nextLine();
					
					int result = num + 8;
					
					System.out.printf("Success! you now have %d Press. Cooker",result);
				}
				if (choice.equals("R") || choice.equals("r"))
				{
					System.out.println("Okay, how much would you like to remove: ");
					int num = s.nextInt(); s.nextLine();
					
					int result = 8 - num;
					
					System.out.printf("Success! you now have %d Press. Cooker ",result);
					if (result <= psrlv)
					{
						System.out.println("\n* However, you have to order more Press. Cooker because the Stock level is equal to or below the Reorder level *");
					}
				}
		}
		
		if(sel.equals("h") || sel.equals("H"))
		{
			int prlv = 8;
			System.out.println("Would you like to add or remove from the item 10''F/Pans (A = add, R = remove)");
			String choice = s.nextLine();
				if (choice.equals("A") || choice.equals("a"))
				{
					System.out.println("Okay, how much would you like to add: ");
					int num = s.nextInt(); s.nextLine();
					
					int result = num + 8;
					
					System.out.printf("Success! you now have %d 10''F/Pans",result);
				}
				if (choice.equals("R") || choice.equals("r"))
				{
					System.out.println("Okay, how much would you like to remove: ");
					int num = s.nextInt(); s.nextLine();
					
					int result = 8 - num;
					
					System.out.printf("Success! you now have %d 10''F/Pans ",result);
					if (result <= prlv)
					{
						System.out.println("\n* However, you have to order more 10''F/Pans because the Stock level is equal to or below the Reorder level *");
					}
				}
		}
		
		if(sel.equals("i") || sel.equals("I"))
		{
			int pfrlv = 12;
			System.out.println("Would you like to add or remove from the item 6P-Fd Ctnr (A = add, R = remove)");
			String choice = s.nextLine();
				if (choice.equals("A") || choice.equals("a"))
				{
					System.out.println("Okay, how much would you like to add: ");
					int num = s.nextInt(); s.nextLine();
					
					int result = num + 14;
					
					System.out.printf("Success! you now have %d 6P-Fd Ctnr",result);
				}
				if (choice.equals("R") || choice.equals("r"))
				{
					System.out.println("Okay, how much would you like to remove: ");
					int num = s.nextInt(); s.nextLine();
					
					int result = 14 - num;
					
					System.out.printf("Success! you now have %d 6P-Fd Ctnr ",result);
					if (result <= pfrlv)
					{
						System.out.println("\n* However, you have to order more 6P-Fd Ctnr because the Stock level is equal to or below the Reorder level *");
					}
				}
		}
		
		if(sel.equals("j") || sel.equals("J"))
		{
			int brlv = 10;
			System.out.println("Would you like to add or remove from the item 3Qt A/Fr (A = add, R = remove)");
			String choice = s.nextLine();
				if (choice.equals("A") || choice.equals("a"))
				{
					System.out.println("Okay, how much would you like to add: ");
					int num = s.nextInt(); s.nextLine();
					
					int result = num + 12;
					
					System.out.printf("Success! you now have %d 3Qt A/Fr",result);
				}
				if (choice.equals("R") || choice.equals("r"))
				{
					System.out.println("Okay, how much would you like to remove: ");
					int num = s.nextInt(); s.nextLine();
					
					int result = 12 - num;
					
					System.out.printf("Success! you now have %d 3Qt A/Fr ",result);
					if (result <= brlv)
					{
						System.out.println("\n* However, you have to order more 3Qt A/Fr because the Stock level is equal to or below the Reorder level *");
					}
				}
		}
						
							
			//s.close();
				

		}
	}

