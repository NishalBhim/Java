
import java.util.Scanner;

public class Supplier {
	
	public void info()
	{
		//Current Suppliers information//
		System.out.println("\n\t*************************************************");
		System.out.println("\n\t*\tC U R R E N T\tS U P P L I E R S\t*");
		System.out.println("\n\t*************************************************");
		System.out.println("______________________________________________________________________________");
		System.out.println("Supplier ID\tSupplier Name\t\tContact #\t\tCredit Limit");
		System.out.println("______________________________________________________________________________");
		System.out.println("\nS1\t\tBest Buy\t\t1868-111-1111\t\t$4000.00");
		System.out.println("\nS2\t\tRight Price\t\t1868-222-2222\t\t$5000.00");
		System.out.println("\nS3\t\tTop Quality\t\t1868-333-3333\t\t$3500.00");
		System.out.println("______________________________________________________________________________");
	}
	
	public void add()
	{
		Scanner scan = new Scanner(System.in);
		
		//Prompts the Sales rep to enter the Supplier's information//
		System.out.println("Enter the Supplier's information separated by a comma:\n[Format: Name > Phone# > Credit Limit] ");
		String info = scan.nextLine();
		
		System.out.printf("\n[%s] has been successfully added",info);   //Success message//
		
		
	}
	
	public void update()
	{
		String sel;
		
		Scanner scan = new Scanner(System.in);
		
		//Prompts the Sales rep to select a Supplier to update//
		System.out.println("Which Supplier would you like to update?\n(a) Best Buy\n(b) Right Price\n(c) Top Quality");
		sel = scan.nextLine();
		
			//IF statements that outlines what will be done based on the Sales rep's selection//
			if (sel.equals("A") || sel.equals("a"))
			{
				String choice;
				String item;
				
				//Prompts the Sales rep to either add or or remove a Supplier//
				System.out.println("Would you like to add an item received from Best Buy or remove Best Buy? (A = add, R = Remove):");
				choice = scan.nextLine();
				
					//IF statements that shows what will happen based on the Sales rep's selection//
					if (choice.equals("A") || choice.equals("a"))
					{
						System.out.println("Okay, enter the item's information separated by a comma:\n[Format: ID > Name > Category > Unit Cost > Reorder Level > Stock Level > Quantity Bought]");
						item = scan.nextLine();
						
						System.out.printf("\n[%s] has been successfully added",item);   //success message//
					}
					
					//IF statements that shows what will happen if the choice is 'R' or 'r'//
					if (choice.equals("R") || choice.equals("r"))
					{
						System.out.println("Okay, Best Buy has been successfully removed");   //success message//
					}
			}
			
			if (sel.equals("B") || sel.equals("b"))
			{
				String choice;
				String item;
				System.out.println("Would you like to add an item received from Right Price or remove Right Price? (A = add, R = Remove):");
				choice = scan.nextLine();
				
					if (choice.equals("A") || choice.equals("a"))
					{
						System.out.println("Okay, enter the item's information separated by a comma:\n[Format: ID > Name > Category > Unit Cost > Reorder Level > Stock Level > Quantity Bought]");
						item = scan.nextLine();
						
						System.out.printf("\n[%s] has been successfully added",item);
					}
					
					if (choice.equals("R") || choice.equals("r"))
					{
						System.out.println("Okay, Right Price has been successfully removed");
					}
			}
			
			if (sel.equals("C") || sel.equals("c"))
			{
				String choice;
				String item;
				System.out.println("Would you like to add an item received from Top Quality or remove Top Quality? (A = add, R = Remove):");
				choice = scan.nextLine();
				
					if (choice.equals("A") || choice.equals("a"))
					{
						System.out.println("Okay, enter the item's information separated by a comma:\n[Format: ID > Name > Category > Unit Cost > Reorder Level > Stock Level > Quantity Bought]");
						item = scan.nextLine();
						
						System.out.printf("\n[%s] has been successfully added",item);
					}
					
					if (choice.equals("R") || choice.equals("r"))
					{
						System.out.println("Okay, Top Quality has been successfully removed");
					}
			}
			
	}

}
