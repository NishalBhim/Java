
public abstract class CurrentInventory {
	
	public void display()
	{
		//Displays the contents of the current inventory/default inventory//
		System.out.println("\t\t\t\t\t*************************************************");
		System.out.println("\n\t\t\t\t\t*\tC U R R E N T\tI N V E N T O R Y\t*");
		System.out.println("\n\t\t\t\t\t*************************************************");
		System.out.println("___________________________________________________________________________________________________________________________");
		System.out.println("ID\t\tName\t\tCategory\tUnit Cost\tReorder Lev\tStock Lev\tSupplier\tQty Bought");
		System.out.println("___________________________________________________________________________________________________________________________");		
		System.out.println("\nI-10001HD\tPower Drill\tTools\t\t$350.00\t\t12\t\t18\t\tBest Buy\t0");
		System.out.println("\nI-10002HD\tUtil Hammer\tTools\t\t$114.50\t\t10\t\t16\t\tBest Buy\t0");
		System.out.println("\nI-10003PH\tScrewdriver\tTools\t\t$47.95\t\t10\t\t11\t\tBest Buy\t0");
		System.out.println("\nI-10004FH\tScrewdriver\tTools\t\t$39.45\t\t10\t\t22\t\tBest Buy\t0");
		System.out.println("\nI-20001Ft\tStep T/Can\tHome-Jn\t\t$114.20\t\t5\t\t7\t\tRight Price\t0");
		System.out.println("\nI-20002\t\tLiq. Soap Disp\tHome-Jn\t\t$48.50\t\t10\t\t13\t\tRight Price\t0");
		System.out.println("\nI-30001\t\tPress. Cooker\tKitchen\t\t$238.45\t\t5\t\t8\t\tTop Quality\t0");
		System.out.println("\nI-30002\t\tCop. 10”F/Pan\tKitchen\t\t$195.95\t\t8\t\t8\t\tTop Quality\t0");
		System.out.println("\nI-30003\t\tRM 6P-Fd Ctnr\tKitchen\t\t$94.85\t\t12\t\t14\t\tTop Quality\t0");
		System.out.println("\nI-30004\t\tBrio 3Qt A/Fr\tKitchen\t\t$432.55\t\t10\t\t12\t\tTop Quality\t0");
		System.out.println("___________________________________________________________________________________________________________________________");

	}

}
