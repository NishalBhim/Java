
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		String choice;
		
		Salesrep sr = new Salesrep();
		Manager m = new Manager();
		
		
			try 
			{
				do {   //Do-while to keep the user in a loop unless terminated by the user//
					
					//Greeting message//
					System.out.println("______________________________________________________________________________________________");
					System.out.println("\nGood day :) Welcome to the Phase 1 Prototype of the Busy Builders Inventory Management System");
					System.out.println("______________________________________________________________________________________________");
					System.out.println("\nPlease state whether you are the Sales Rep or the Manager (S = Sales rep, M = Manager): ");   //Prompting the user to identify themselves//
					choice = scan.nextLine();
					
					//IF statements that calls the method of the corresponding class based on the user's input//
					if (choice.toUpperCase().equals("S")) //accepts both lower and upper case responses//
					{
						sr.task();
						break;   //breaks the loop when the method is completed//
					}
					
					if (choice.toUpperCase().equals("M"))
					{
						m.task();
						break;
					}
					
					if (!choice.toUpperCase().equals("S") || choice.toUpperCase().equals("M"))
					{
						System.out.println("\n\nError - Invalid Entry, Please select 's/S' or 'm/M'\n\n");   //error message//
					}			
							
					
				} while (!(choice.toUpperCase().equals("S") || choice.toUpperCase().equals("M")));
			}
			
			//catches the error//
			catch (Exception e)
			{
				System.out.println(e);
		        e.printStackTrace();
			}
			
		scan.close();		

	}

}
