
public class InvenReport extends CurrentInventory{
	//Class that extends to the CurrentInventory class//
}
