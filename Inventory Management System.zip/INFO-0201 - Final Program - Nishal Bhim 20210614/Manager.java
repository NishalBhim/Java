
import java.util.Scanner;

public class Manager {
	
	public void task()
	
	{
		InvenReport in = new InvenReport();
		Sales s = new Sales();
		
		String choice = null;
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("\nHello Manager, what would you like to do today?\n(a) View Inventory Levels\n(b) View Monthly Sales Transactions");

		//Exception handling to ensure that the valid entry is accepted, otherwise display an error message// 
		try
		{
			do {   //DO-While loop to keep the manager in the loop unless terminated by him/her//
				choice = scan.nextLine();
				
				do {
					
					//IF statements that accepts both upper and lower case responses//
					if (choice.toUpperCase().equals("A"))
					{
						in.display();
						break;
					}
					if (choice.toUpperCase().equals("B"))
					{
						s.transactions();
						break;
					}
					
					if (!(choice.toUpperCase().equals("A") || choice.toUpperCase().equals("B")))
					{
						System.out.println("\n\n Error - Choose a/A or b/B Please\n\n");   //Error message//						
					}
					
				} while (!(choice.toUpperCase().equals("A") || choice.toUpperCase().equals("B")));
		
				do {   //Internal DO-While loop to prompt the manager to continue//
					
				System.out.println("\nWould you like to continue Manager (Y or N)?");	
								
				choice = scan.nextLine();
				
				//IF statements that repeat the contents of the 'task' method for the Manager class until the manager terminates the program//
					if (choice.toUpperCase().equals("Y") ) {
						System.out.println("\nHello Manager, what would you like to do today?\n(a) View Inventory Levels\n(b) View Monthly Sales Transactions");
					}
					
					if (choice.toUpperCase().equals("N") ) {
						break;
					}
					
					if (!(choice.toUpperCase().equals("Y") || choice.toUpperCase().equals("N")))
					{
						System.out.println("\n\n Error - Choose y/Y or n/N Please \n\n");						
					}
					
				} while (!(choice.toUpperCase().equals("Y")||choice.toUpperCase().equals("N")));			
					
		
			} while (choice.toUpperCase().equals("Y"));		
			
			System.out.println("Okay you have been logged out, have a blessed day Manager :)");
		}
		
		catch (Exception e)
		{
			System.out.println(e);
	        e.printStackTrace();
		}
		
	    scan.close();
	}

}