import java.util.Scanner;

public class Circle 
{
	//Instance Variable Declaration//
	private double radius;
	private String color = "black";
	
	Scanner scan = new Scanner(System.in);   //Scanner Utility to allow user input//
	
	Circle (double radius, String color){}   //Statement that identifies the parameters of the Circle Constructor//
	
	Circle (double newRadius)   //Statement that informs the program that it will be accepting a new radius//
	{
		radius = newRadius;   //Statement that sets the 'radius' Instance Variable to store the new radius entered by the user//
	}
	
		public void ChangeRadius (double newRadius)   //'ChangeRadius' Instance Method statement to change the radius from the initial radius to the new radius identifying the 'newRadius' parameter// 
		{
			radius = newRadius;   ///Statement that sets the 'radius' Instance Variable to store the new radius entered by the user//
		}
		public String getnewRadius()   //'getnewRadius' Instance Method that acts as a Getter to obtain the new radius value// 
		{
			System.out.println("Enter a value for radius: ");   //Statement that prompts the user to enter the new radius//
			radius = scan.nextDouble();   //Statement that stores the new radius value into the 'radius' Instance Variable//
			return "The New Radius is: "+radius+"cm";   //Statement that returns the new radius in an appropriate format//
		}
		public String getcolor()   //'getcolor' Instance Method that acts as a Getter to obtain the initial color of the circle//  
		{
			return "The Color of the circle is: "+color+"";   //Statement that returns the initial color of the circle in an appropriate format//
		}
		public void getDiameter()   //'getDiameter' Instance Method to obtain the diameter of the circle// 
		{
			double diameter = (2 * radius);   //Statement that calculates the diameter of the circle and stores the result in the 'diameter' Instance Variable//
			System.out.printf("The Diameter of the circle is: " +diameter+ "cm");   //Statement that displays the diameter of the circle in an appropriate format//
		}
		public void getArea()   //'getArea' Instance Method to obtain the area of the circle//
		{
			double area = (3.154*(radius*radius));   //Statement that calculates the area of the circle and stores the result in the 'area' Instance Variable//
			System.out.println("\nThe Area of the circle is: " +area+ "cm^2");   //Statement that displays the area of the circle in an appropriate format//
		}
		
	}


