//Name: Nishal Bhim//

//Student ID#: 20210614//

//Course Code: INFO-0201//

//Course Name: Object-Oriented Programming//

//Date: 9th October 2022//

//Lecturer: Dr. Steve Warner//

//Assignment: Assignment #2 - Calculating the Area and Diameter of a Circle//

//Program Name: Calculating the Area and Diameter of a Circle//

//Program Description: This program will use calculate the Area and Diameter of a Circle derived from a user inputted radius value along with the initial color of the circle// 

public class Main {

	public static void main(String[] args) {
	

		Circle c = new Circle (0.0, "Black");   //Statement that identifies the Circle class/Default Constructor, the 'c' object and the initial parameters of the Circle class/Default Constructor//
		
		c.ChangeRadius(0);   //Statement that calls the 'ChangeRadius' Instance Method using the 'c' object//  
		System.out.println(c.getnewRadius());   //Statement that displays the new radius entered by the user//
		
		System.out.println(c.getcolor());   //Statement that displays the initial color of the circle//
		
		c.getDiameter();   //Statement that calls the 'getDiameter' Instance Method using the 'c' object// 
		c.getArea();   //Statement that calls the 'getArea' Instance Method using the 'c' object// 
		
		
	}

}
