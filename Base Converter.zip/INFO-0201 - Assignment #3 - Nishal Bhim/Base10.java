import java.util.Scanner;

public class Base10 {
	
	Scanner base = new Scanner (System.in);
	
	Loop l = new Loop();   //Initializes the 'l' object//
	
	public void convert()
	{
		System.out.println("Enter the base you want to convert to (2, 8, 16): ");   //prompts user to enter the base to be converted to//
		int newbase = base.nextInt();
		
		//IF statements that does not accept bases that are outside of the program's parameters//
			if (newbase > 16)
			{
				System.out.printf("\n* Error: Invalid entry, program does not facilitate base %d *",newbase);
				System.out.println("\n\nPlease try again: ");
				newbase = base.nextInt();
			}
			if (newbase < 2)
			{
				System.out.printf("\n* Error: Invalid entry, program does not facilitate base %d *",newbase);
				System.out.println("\n\nPlease try again: ");
				newbase = base.nextInt();
			}
		
		//IF statement that determines the outcome if the base is base 2//
		if (newbase == 2)
		{
				System.out.println("Enter the number that you want to convert: ");   
				int num = base.nextInt();
			
			//Calculations that convert the entered value to base 2//
			int res = 0;
			int pow = 0;
			int b = 2;
				while (num != 0)
				{
					int rem = num % b;
					res += rem*Math.pow(10, pow);
					num = num/b;
					pow += 1;
				}
				System.out.println("\n_______________________");
				System.out.printf("\n* The answer is: %d(2) *",res);
				System.out.println("\n_______________________");
					
		}
		
		//IF statement that determines the outcome if the base is base 8//
		if (newbase == 8)
		{
				System.out.println("Enter the number that you want to convert: ");   //prompts the user to enter a numerical value//
				int num = base.nextInt();
			
			//Calculations that convert the entered value to base 8//
			int res = 0;
			int pow = 0;
			int b = 8;
				while (num != 0)
				{
					int rem = num % b;
					res += rem*Math.pow(10, pow);
					num = num/b;
					pow += 1;
				}
				System.out.println("\n_______________________");
				System.out.printf("\n* The answer is: %d(8) *",res);
				System.out.println("\n_______________________");
		}
		
		//IF statement that determines the outcome if the base is base 16//
		if (newbase == 16)
		{
				System.out.println("Enter the number that you want to convert: ");
				int num = base.nextInt();
			
			//Calculations that convert the entered value to base 16//
			char hex [] = {'0','1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
			String HexVal = "";
			int b = 16;
				while (num != 0)
				{
					int rem = num % b;
					HexVal = hex [rem] + HexVal;
					num = num/b;
				}
				System.out.println("\n_______________________");
				System.out.printf("\n* The answer is: %s(16) *",HexVal);
				System.out.println("\n_______________________");
		}
		
		l.repeat();
	}

}
