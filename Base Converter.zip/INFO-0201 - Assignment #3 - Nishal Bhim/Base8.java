import java.util.Scanner;

public class Base8 {
	
	Scanner base = new Scanner (System.in);
	
	Loop l = new Loop();   //Initializes the 'l' object//
	
	public void convert()
	{
		//Variable Declaration//
		int num;
		int decnum;
		int pow;
		int rem;
		int res;
		int b;
		
		System.out.println("Enter the base you want to convert to (2, 10, 16): ");   //prompts user to enter the base to be converted to//
		int newbase = base.nextInt();
		
			//IF statements that does not accept bases that are outside of the program's parameters//
			if (newbase > 16)
			{
				System.out.printf("\n* Error: Invalid entry, program does not facilitate base %d *",newbase);
				System.out.println("\n\nPlease try again: ");
				newbase = base.nextInt();
			}
			if (newbase < 2)
			{
				System.out.printf("\n* Error: Invalid entry, program does not facilitate base %d *",newbase);
				System.out.println("\n\nPlease try again: ");
				newbase = base.nextInt();
			}
		
			//IF statement that determines the outcome if the base is base 2//
			if (newbase == 2)
			{
					System.out.println("Enter the number that you want to convert: ");   //prompts the user to enter a numerical value//
					num = base.nextInt();
					
					//Calculations that first convert the numeric value entered to base 10//
					decnum = 0;
					pow = 0;
						while (num > 0)
						{
							rem = num%10;
							decnum += rem*Math.pow(8, pow);
							pow += 1;
							num /= 10;
						}
						
						//Calculations that then convert the base 10 equivalent to the specified base//
						res = 0;
						pow = 0;
						b = 2;
							while (decnum != 0)
							{
								rem = decnum % b;
								res += rem*Math.pow(10, pow);
								decnum = decnum/b;
								pow += 1;
							}
							
							//Statements that displays the result in an appropriate format//
							System.out.println("_______________________");
							System.out.printf("\n* The answer is: %d(2) *",res);
							System.out.println("\n_______________________");
			}
			
			//IF statement that determines the outcome if the base is base 10//
			if (newbase == 10)
			{
					System.out.println("Enter the number that you want to convert: ");
					num = base.nextInt();
					
					//Calculations that first convert the numeric value entered to base 10//
					decnum = 0;
					pow = 0;
						while (num > 0)
						{
							rem = num%10;
							decnum += rem*Math.pow(8, pow);
							pow += 1;
							num /= 10;
						}
						
						//Calculations that then convert the base 10 equivalent to the specified base//
						res = 0;
						pow = 0;
						b = 10;
							while (decnum != 0)
							{
								rem = decnum % b;
								res += rem*Math.pow(10, pow);
								decnum = decnum/b;
								pow += 1;
							}
							System.out.println("_______________________");
							System.out.printf("\n* The answer is: %d(10) *",res);
							System.out.println("\n_______________________");
			}
			
			//IF statement that determines the outcome if the base is base 16//
			if (newbase == 16)
			{
					System.out.println("Enter the number that you want to convert: ");
					num = base.nextInt();
					
					//Calculations that first convert the numeric value entered to base 10//
					decnum = 0;
					pow = 0;
						while (num > 0)
						{
							rem = num%10;
							decnum += rem*Math.pow(8, pow);
							pow += 1;
							num /= 10;
						}
						
						//Calculations that then convert the base 10 equivalent to the specified base//
						char hex [] = {'0','1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
						String HexVal = "";
						pow = 0;
						b = 16;
							while (decnum != 0)
							{
								rem = decnum % b;
								HexVal = hex [rem] + HexVal;
								decnum = decnum/b;
								pow += 1;
							}
							System.out.println("_______________________");
							System.out.printf("\n* The answer is: %s(16) *",HexVal);
							System.out.println("\n_______________________");
			}
			
			l.repeat();
	}

}
