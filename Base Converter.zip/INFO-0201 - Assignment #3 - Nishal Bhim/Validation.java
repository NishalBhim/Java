import java.util.Scanner;

public class Validation {
	
	public void check()
	{
		int base;
		
		Scanner scan = new Scanner (System.in);
		
		//Initialization of objects for the different bases//
		Base2 b2 = new Base2();
		Base8 b8 = new Base8();
		Base10 b10 = new Base10();
		Base16 b16 = new Base16();
		
		//Initialization of the 'l' object to maintain a loop unless exited by the user//
		Loop l = new Loop();
		
		System.out.println("\nEnter the initial base: ");   //prompts the user for an initial base//
		base = scan.nextInt();
			
	
			//IF statements that call the corresponding method of the chosen base//
			if (base == 2)
			{
				b2.convert();
			}
			if (base == 8)
			{
				b8.convert();
			}
			if (base == 10)
			{
				b10.convert();
			}
			if (base == 16)
			{
				b16.convert();
			}
			
		//IF statements that does not accept bases that are outside of the program's parameters and prompts the user to re-enter//
		if (base < 2 )
		{
			System.out.println("\n* Error: Base is < 2 *");
			l.repeat();   //calls the 'repeat' method using the 'l' object//
		}
		if (base > 16 )
		{
			System.out.println("\n* Error: Base is > 16 *");
			l.repeat();   //calls the 'repeat' method using the 'l' object//
		}
			
			scan.close();   //closes the scanner//
	}

}