import java.util.Scanner;

//Name: Nishal Bhim//

//Student ID#: 20210614//

//Course Code: INFO-0201//

//Course Name: Object-Oriented Programming//

//Date: 31st October 2022//

//Lecturer: Dr. Steve Warner//

//Assignment: Assignment #3 - Base Conversion//

//Program Name: Base Converter Program//

//Program Description: This program will accept user input in terms of an initial base, the base that the number will be converted to and the number that is to be converted//

public class Chbase {

	public static void main(String[] args) {
		
		
		Scanner scan = new Scanner(System.in);   //Initializes 'scan' object//
		
		Validation val = new Validation();   //Initializes 'val' object//
		
		//Welcome message//
		System.out.println("**********************************************************************************************************************");
		System.out.println("Welcome to the Base Converter Program :)\t\t\t\t\t");
		System.out.println("\nThis program will accept an initial base, a base to which the number entered will be converted and a number as input");
		System.out.println("\t______________________________________________________");
		System.out.println("\n\tNote: The bases that this program facilitates are:\n\t______________________________________________________\n\n-Base 2 (Binary)\n-Base 8 (Octal)\n-Base 10 (Decimal)\n-Base 16 (Hexadecimal)\n\nHappy Converting :)");
		System.out.println("**********************************************************************************************************************");

		val.check();   //calls the 'check' method using the 'val' object//
			
		scan.close();   //closes the scanner object//
		
	}

}
