import java.util.Scanner;

public class Loop {
	
	public void repeat ()
	{
		String choice;
		
		Scanner scan = new Scanner (System.in);
		
		
		Validation val = new Validation();
		
		System.out.println("\nWould you like to continue (Y/y or N/n)? ");   //prompts the user to continue//
		choice = scan.nextLine();
		
		
		//IF statement that shows if yes is selected//
		if (choice.equals("Y") || choice.equals("y"))   //Statement that allows the program to run regardless of upper or lower case letter entered//
		{
			val.check();   //calls the 'check' method using the 'val' object//
		}
		
		//IF statement that shows if no is selected//
		if (choice.equals("N") || choice.equals("n"))   //Statement that allows the program to run regardless of upper or lower case letter entered// 
		{
			System.out.println("Okay have a blessed day :) ");   //Closing message//
		}
		
	scan.close();   //closes the scanner//
		
	}

}
